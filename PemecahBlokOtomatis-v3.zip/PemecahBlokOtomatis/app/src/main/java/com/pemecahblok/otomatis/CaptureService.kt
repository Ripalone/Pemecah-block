package com.pemecahblok.otomatis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.io.ByteArrayOutputStream

/**
 * Menahan izin rekam layar, menyimpan frame terbaru, dan menampilkan panel WebView di atas layar.
 * Semua pembacaan papan dan pencarian langkah dikerjakan oleh assets/panel.html.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1
        private const val CAP_W = 720            // lebar yang diharapkan pembaca di panel.html
        private const val AUTO_INTERVAL_MS = 1200L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var bgThread: HandlerThread
    private lateinit var bg: Handler
    private lateinit var wm: WindowManager

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private val lock = Any()

    private var webView: WebView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var screenH = 0
    private var density = 1f
    private var screenScale = 1f          // piksel layar per piksel bingkai (720 lebar)
    private var panelPct = 28
    private var auto = false
    private var stopping = false

    private val autoTick = object : Runnable {
        override fun run() {
            if (!auto) return
            bg.post { captureAndSend(false) }
            main.postDelayed(this, AUTO_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null || code == 0 || projection != null) return START_NOT_STICKY

        startAsForeground()
        bgThread = HandlerThread("capture").also { it.start() }
        bg = Handler(bgThread.looper)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        panelPct = getSharedPreferences("cfg", MODE_PRIVATE).getInt("pct", 28)

        try {
            setupCapture(code, data)
            addPanel()
        } catch (e: Exception) {
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pembacaan layar", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Pemecah Blok Otomatis aktif")
            .setContentText("Ketuk Berhenti untuk menutup panel")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun setupCapture(code: Int, data: Intent) {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        screenH = m.heightPixels
        screenScale = m.widthPixels / CAP_W.toFloat()
        // Tangkap langsung di lebar 720 supaya cocok dengan pembaca di panel.html
        val capH = (CAP_W.toFloat() * m.heightPixels / m.widthPixels).toInt()

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)
        projection = p

        val r = ImageReader.newInstance(CAP_W, capH, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { held?.close(); held = img }
        }, bg)
        reader = r
        display = p.createVirtualDisplay(
            "pemecah-blok", CAP_W, capH, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun addPanel() {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/panel.html")
        webView = wv

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            expandedPx(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        panelParams = lp
        wm.addView(wv, lp)
    }

    private fun expandedPx() = (screenH * panelPct / 100f).toInt()
    private fun collapsedPx() = (64 * density).toInt()

    /** Ambil frame terbaru, ubah ke JPEG, lalu kirim ke panel. Dijalankan di thread latar. */
    private fun captureAndSend(manual: Boolean) {
        val b64: String = synchronized(lock) {
            val img = held ?: return
            val plane = img.planes[0]
            val rowPad = plane.rowStride - plane.pixelStride * img.width
            val wide = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            plane.buffer.rewind()
            wide.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (rowPad == 0) wide else Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
            if (bmp !== wide) bmp.recycle()
            wide.recycle()
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }
        main.post {
            webView?.evaluateJavascript("window.onFrame('data:image/jpeg;base64,$b64', $manual)", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun requestScan() { bg.post { captureAndSend(true) } }

        @JavascriptInterface fun setAuto(on: Boolean) {
            main.post {
                auto = on
                main.removeCallbacks(autoTick)
                if (on) main.post(autoTick)
            }
        }

        @JavascriptInterface fun setExpanded(on: Boolean) {
            main.post {
                val lp = panelParams ?: return@post
                lp.height = if (on) expandedPx() else collapsedPx()
                webView?.let { wm.updateViewLayout(it, lp) }
            }
        }

        @JavascriptInterface fun stop() { main.post { shutdown() } }

        /** True kalau izin Aksesibilitas "Tangan Otomatis" sudah menyala. */
        @JavascriptInterface fun canTap(): Boolean = AutoTapService.instance != null

        @JavascriptInterface fun openAccessibility() {
            main.post {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }
        }

        /** Geser dari titik (x1,y1) ke (x2,y2) dalam koordinat bingkai 720 lebar. Hasil dikirim lewat onDragDone. */
        @JavascriptInterface fun drag(x1: Double, y1: Double, x2: Double, y2: Double) {
            main.post {
                val svc = AutoTapService.instance
                if (svc == null) { dragDone(false); return@post }
                val s = screenScale
                val accepted = svc.drag(
                    (x1 * s).toFloat(), (y1 * s).toFloat(), (x2 * s).toFloat(), (y2 * s).toFloat(), 450L
                ) { ok -> main.post { dragDone(ok) } }
                if (!accepted) dragDone(false)
            }
        }
    }

    private fun dragDone(ok: Boolean) {
        webView?.evaluateJavascript("window.onDragDone($ok)", null)
    }

    private fun shutdown() {
        if (stopping) return
        stopping = true
        auto = false
        main.removeCallbacksAndMessages(null)
        try { webView?.let { wm.removeView(it); it.destroy() } } catch (_: Exception) {}
        webView = null
        try { display?.release() } catch (_: Exception) {}
        synchronized(lock) { held?.close(); held = null }
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        if (::bgThread.isInitialized) bgThread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
