package com.pemecahblok.otomatis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqOverlay = 1
    private val reqCapture = 2
    private val reqNotif = 3

    private lateinit var pctLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun text(t: String, sp: Float, bold: Boolean = false, bottom: Int = 12) = TextView(this).apply {
            this.text = t
            textSize = sp
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, (bottom * d).toInt())
        }

        root.addView(text("Pemecah Blok Otomatis", 26f, true, 6))
        root.addView(
            text(
                "Panel kecil muncul di bagian atas layar game. Panel membaca papan dan tiga potongan " +
                    "secara otomatis lalu menunjukkan taruh potongan di mana. Tekan Main di panel supaya potongan digeser otomatis.",
                15f, false, 18
            )
        )

        val pct = prefs.getInt("pct", 28)
        pctLabel = text("Tinggi panel: $pct% dari layar", 15f, true, 4)
        root.addView(pctLabel)
        root.addView(SeekBar(this).apply {
            max = 20
            progress = pct - 15
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + 15
                    prefs.edit().putInt("pct", v).apply()
                    pctLabel.text = "Tinggi panel: $v% dari layar"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(
            text(
                "Atur supaya panel tidak menutupi papan game. Di game Gojek papan mulai sekitar 31% dari atas, jadi 28% aman.",
                13f, false, 20
            )
        )

        root.addView(Button(this).apply {
            text = "Mulai"
            setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "Aktifkan Tangan Otomatis (Aksesibilitas)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Berhenti"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            }
        })

        root.addView(
            text(
                "\nCara pakai:\n" +
                    "1. Tekan Mulai, izinkan tampil di atas aplikasi lain, lalu izinkan rekam layar (pilih seluruh layar).\n" +
                    "2. Buka game. Panel muncul di atas.\n" +
                    "3. Tekan Pindai, atau nyalakan Auto supaya panel memperbarui langkah sendiri tiap potongan baru muncul.\n" +
                    "4. Ikuti nomor 1, 2, 3 di mini papan, atau aktifkan Tangan Otomatis lalu tekan Main supaya digeser sendiri.\n" +
                    "5. Kalau blok mendarat bergeser dari sel tujuan, ketuk Tarik di panel sampai pas.",
                14f, false, 0
            ).apply { gravity = Gravity.START }
        )

        setContentView(ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addView(root)
        })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" lalu kembali.", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                reqOverlay
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqOverlay -> if (Settings.canDrawOverlays(this)) start()
            reqCapture -> {
                if (resultCode == RESULT_OK && data != null) {
                    val i = Intent(this, CaptureService::class.java)
                        .putExtra(CaptureService.EXTRA_CODE, resultCode)
                        .putExtra(CaptureService.EXTRA_DATA, data)
                    startForegroundService(i)
                    Toast.makeText(this, "Siap. Buka game sekarang.", Toast.LENGTH_SHORT).show()
                    moveTaskToBack(true)
                } else {
                    Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) start()
    }
}
