package com.pemecahblok.otomatis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * "Tangan" aplikasi: menggeser jari di layar atas perintah panel.
 * Aktifkan di Pengaturan > Aksesibilitas > Pemecah Blok - Tangan Otomatis.
 */
class AutoTapService : AccessibilityService() {

    companion object {
        @Volatile var instance: AutoTapService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Geser dari (x1,y1) ke (x2,y2) dalam piksel layar. Mengembalikan false kalau gesture ditolak sistem. */
    fun drag(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, done: (Boolean) -> Unit): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done(true) }
            override fun onCancelled(g: GestureDescription?) { done(false) }
        }, null)
    }
}
