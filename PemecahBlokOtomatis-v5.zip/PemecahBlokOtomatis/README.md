# Pemecah Blok Otomatis

Panel melayang di atas game blok. Membaca papan dan tiga potongan langsung dari layar,
lalu menampilkan urutan dan posisi taruh potongan. Kamu tetap menaruh potongan sendiri.

## Cara membuat APK

### Opsi A: Android Studio
1. Buka folder ini dengan Android Studio (Open).
2. Tunggu sinkronisasi Gradle selesai.
3. Menu Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk

### Opsi B: GitHub Actions (tanpa komputer)
1. Buat repositori baru di GitHub dan unggah seluruh isi folder ini (termasuk folder .github).
2. Buka tab Actions > Build APK > Run workflow.
3. Setelah selesai, unduh artefak PemecahBlokOtomatis-debug (isinya app-debug.apk).

## Cara pakai
1. Pasang APK, buka aplikasi, tekan Mulai.
2. Izinkan "Tampil di atas aplikasi lain", lalu izinkan rekam layar (pilih seluruh layar).
3. Buka game. Panel muncul di atas.
4. Pindai = baca sekali. Auto = baca tiap 1,2 detik dan hitung ulang saat potongan baru muncul.
5. Ketuk papan mini untuk pindah langkah.

## Struktur
- app/src/main/assets/panel.html : pembaca layar + pencari langkah (dari pemecah-blok.html) dan tampilan panel
- CaptureService.kt : rekam layar, panel melayang, jembatan ke panel.html
- MainActivity.kt : izin dan tombol Mulai/Berhenti, pengaturan tinggi panel

## Menguji panel.html di browser
Buka panel.html di browser, tekan Pindai, pilih screenshot game. Tanpa Android, tombol itu memakai pemilih file.
